// test.cpp : Defines the entry point for the console application.
//
//#include "stdafx.h"
#include "conio.h"
#include "windows.h"
#include <math.h> 
#include <iostream>
using namespace std;
#define N            2
#define TRUE          1

HANDLE hSemaphore = NULL;
HANDLE s[N];
int state[N];
const int threads_num = N;              //������������
int Index = 0;
HANDLE Threads[threads_num];
HANDLE hMutex;
long dwSem = 0;
boolean flag[2] = { false,false };
int turn=0;
int num;

typedef struct MyData
{
	int index;
}MYDATA;

void Process1(){
	do{
		flag[0] = true;
		turn = 1; //��ʱP0δ�����ٽ����� ��Ȼ����P1�����ٽ�����
		if (flag[1] && turn == 0) {
			num = num + 1;
			cout << "����1��һ������Ϊ" << num<<endl;
			Sleep(1000);
			flag[0] = false;//��ʾP0�˳��� ���ٽ�����
		}
		

	}while (1);

}
void Process2() {
	do {
		flag[1] = true;
		turn = 0; //��ʱP0δ�����ٽ����� ��Ȼ����P1�����ٽ�����
		if (flag[0] && turn == 1) {
			num = num - 1;
			cout << "����2��һ������Ϊ" << num << endl;
			Sleep(1000);
			flag[1] = false;
		}
	} while (1);

}

 int WINAPI ThreadFun(void* param)
 {
	 bool isCompleted = false;
	 int myindex = 0;
	 MYDATA* pmd = (MYDATA*)param;
	 myindex = pmd->index;
	 while (!isCompleted)
	 {
		Process1();
		 isCompleted = true;
	 }
	 return 0;
 }
 int WINAPI ThreadFun1(void* param)
 {
	 bool isCompleted = false;
	 int myindex = 0;
	 MYDATA* pmd = (MYDATA*)param;
	 myindex = pmd->index;
	 while (!isCompleted)
	 { 
		Process2();
		isCompleted = true;
	 }
	 return 0;
 }
 void creatThreads()
 {
	 DWORD dwThreadID = 0;
	 MYDATA mydt; 
	 mydt.index = 0;
	 Threads[0] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFun, &mydt, CREATE_SUSPENDED, &dwThreadID);	
	 mydt.index = 1;
	 Threads[1] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFun1, &mydt, CREATE_SUSPENDED, &dwThreadID);
	  for (int j = 0; j < threads_num; ++j)
	  {
     	 ResumeThread(Threads[j]);
		 Sleep(1000);
	  }
 }


 int main(int argc, char* argv[])
 {
	 creatThreads();
	 WaitForMultipleObjects(threads_num, Threads, TRUE, INFINITE);
	 printf("All threads finished!");
	 getchar();
	 return 0;
 }

