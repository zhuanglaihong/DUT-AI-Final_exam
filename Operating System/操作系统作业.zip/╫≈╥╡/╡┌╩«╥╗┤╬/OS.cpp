// test.cpp : Defines the entry point for the console application.
//
//#include "stdafx.h"
#include "conio.h"
#include "windows.h"
#include <math.h> 
#include <iostream>
using namespace std;
#define N            5
#define LEFT         (i+N-1)%N
#define RIGHT        (i+1)%N
#define THINKING      0
#define HUNGRY        1
#define EATING        2
#define TRUE          1

HANDLE hSemaphore = NULL;
HANDLE s[N];
int state[N];
const char* strSemaphoreName = "MySemaphore";
const int threads_num = N;              //���������ѧ��
int Index = 0;
HANDLE Threads[threads_num];
HANDLE hMutex;
long dwSem = 0;

void think(int i) {
	cout << "��ѧ��" << i << "����˼��" << endl;

}
void eat(int i) {
	cout << "��ѧ��" << i << "���ڳԷ�" << endl;
}
typedef struct MyData
{
	int index;
}MYDATA;

void test(int i)
{
	if (state[i] == HUNGRY && state[LEFT] != EATING &&
		state[RIGHT] != EATING)
	{
		state[i] = EATING;
		cout << "��ѧ��" << i << "���ԳԷ���" << endl;
		ReleaseSemaphore(s[i], 1, &dwSem);
	}
}
void take_forks(int i)
{
	WaitForSingleObject(hMutex, INFINITE);
	state[i] = HUNGRY;
	test(i);
	ReleaseMutex(hMutex);
	WaitForSingleObject(s[i], INFINITE);           //�ȴ��ź���
}
void put_forks(int i)
{
	WaitForSingleObject(hMutex, INFINITE);
	state[i] = THINKING;
	test(LEFT);
	test(RIGHT);
	ReleaseMutex(hMutex);
}

void philosopher(int i)      //��ѧ�Һ���
{
	while (TRUE) {
		think(i);
		take_forks(i);
		eat(i);
		Sleep(10000);
		put_forks(i);
		break;
	}
}



 int WINAPI ThreadFun(void* param)
 {
	 bool isCompleted = false;
	 int myindex = 0;
	 MYDATA* pmd = (MYDATA*)param;
	 myindex = pmd->index;
	 while (!isCompleted)
	 {

		 Index = Index + 1;
		 myindex = Index;
		 philosopher(myindex);
		 //ReleaseSemaphore(hSemaphore, 1, &dwSem);
		 isCompleted = true;
	 }
	 return 0;
 }

 void creatThreads()
 {
	 DWORD dwThreadID = 0;
	 MYDATA mydt;
	 for (int i = 0; i < threads_num; ++i)
	 {
		 mydt.index = i;
		 Threads[i] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFun, &mydt, CREATE_SUSPENDED, &dwThreadID);
		 printf("%u �߳� %u �����ɹ�\n", i, dwThreadID);

	 }
	  for (int j = 0; j < threads_num; ++j)
	  {
     	 ResumeThread(Threads[j]);
		 Sleep(1000);
	  }
 }


 int main(int argc, char* argv[])
 {
	 hMutex = CreateMutex(NULL, FALSE, NULL);
	 for (int k = 0; k < 5; k++) {
		 s[k] = CreateSemaphore(NULL, 0, 1, NULL);
	 }
	 hSemaphore = CreateSemaphore(NULL, 6, 6, NULL);   //�����ź���
	 creatThreads();
	 WaitForMultipleObjects(threads_num, Threads, TRUE, INFINITE);
	 printf("All threads finished!");
	 getchar();
	 return 0;
 }

