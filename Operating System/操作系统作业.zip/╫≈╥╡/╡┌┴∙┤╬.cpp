﻿//#include <iostream>
//#include <stdio.h>
//#include "windows.h"
//
//int main()
//{
//
//
//
//    //先获取转换成宽字符后的长度（一定要通过这种方式，先回去字符长度，因为有指定编码为CP_ACP，编码不同，长度也会不同）
//    int nLen1 = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, "open", -1, NULL, 0);
//    //声明一个宽字符类型变量，用于存放转换后的字符
//    wchar_t* wname1 = new wchar_t[nLen1];
//    //利用微软ANSI转宽字符的函数（name:ANSI字符，wname:宽字符）
//    MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, "open", -1, wname1, nLen1);
//
//
//    int nLen2 = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, "http:\\www.google.com", -1, NULL, 0);
//    //声明一个宽字符类型变量，用于存放转换后的字符
//    wchar_t* wname2 = new wchar_t[nLen2];
//    //利用微软ANSI转宽字符的函数（name:ANSI字符，wname:宽字符）
//    MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, "http:\\www.baidu.com", -1, wname2, nLen2);
//
//    ShellExecute(NULL,wname1,wname2,NULL,NULL,SW_SHOW);
//
//    return 0;
//}
//#include <stdio.h>
//#include <tchar.h>
//#include <windows.h>
//
//int main()
//{
//	LPWSTR szCommandLine = (LPWSTR)"calc.exe\0";
//	PROCESS_INFORMATION pi;
//
//
//	LPWSTR filename = (LPWSTR)"notepad\0";
//	LPPROCESS_INFORMATION info = NULL;
//	STARTUPINFO si = { sizeof(si) };
//	si.dwFlags = STARTF_USESHOWWINDOW;
//	si.wShowWindow = TRUE;
//	BOOL bRet= CreateProcess(NULL,
//		szCommandLine,
//		NULL,
//		NULL,
//		FALSE,
//		NULL,
//		NULL,
//		NULL,
//		&si,
//		&pi);
//	if (bRet) {
//		CloseHandle(pi.hThread);
//		CloseHandle(pi.hProcess);
//		printf("新进程的ID号：%d\n",pi.dwProcessId);
//		printf("新进程的主线程ID号：%d\n",pi.dwThreadId);
//	}
//	system("pause");
//	return 0;
//}
//#include "stdafx.h"
//#include <stdio.h>
//
//#include <locale.h>
//#include <cstdlib>
//#include <windows.h>
//#include "psapi.h"
//#pragma   comment   (lib, "psapi.lib ")
//
//
//void MyEnumProcess()
//{
//	// Get the list of process identifiers.
//	DWORD aProcesses[1024], cbNeeded, cProcesses;
//	unsigned int i;
//
//	if (!EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded))       //枚举进程
//		return;
//	cProcesses = cbNeeded / sizeof(DWORD);             //计算进程个数
//	for (i = 0; i < cProcesses; i++)
//		if (aProcesses[i] != 0)
//		{
//
//			TCHAR szProcessName[MAX_PATH] = TEXT("<unknown>");
//			HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, aProcesses[i]);     //获得进程句柄
//
//			if (NULL != hProcess)
//			{
//				HMODULE hMod;
//				DWORD cbNeeded;
//
//				if (EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeeded))        //枚举进程模块信息
//				{
//					GetModuleBaseName(hProcess, hMod, szProcessName, sizeof(szProcessName) / sizeof(TCHAR));       //取得主模块全名,每个进程第一模块则为进程主模块
//				}
//			}
//			printf("%s  (PID: %u)\n", szProcessName, aProcesses[i]);     //输出进程名及PID
//			CloseHandle(hProcess);
//		}
//}
//
//
//void main()
//{
//	MyEnumProcess();
//	system("pause");
//}

//#include "stdafx.h"
#include <stdio.h>
#include <Windows.h>
#include <TlHelp32.h>
#include"conio.h"
#include"string.h"
#include"stdlib.h"

void ShowError(char* lpszText)
{
	LPWSTR szErr = (LPWSTR)"0";

	//char szErr[MAX_PATH] = { 0 };
	::wsprintf(szErr, (LPWSTR) "%s Error[%d]\n", lpszText, ::GetLastError());
#ifdef _DEBUG
	::MessageBox(NULL, szErr, (LPWSTR)"ERROR", MB_OK);
#endif
}


BOOL EnumProcess()
{
	PROCESSENTRY32 pe32 = { 0 };
	pe32.dwSize = sizeof(PROCESSENTRY32);
	// 获取全部进程快照
	HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (INVALID_HANDLE_VALUE == hProcessSnap)
	{
		ShowError(("CreateToolhelp32Snapshot"));
		return FALSE;
	}

	// 获取快照中第一条信息
	BOOL bRet = ::Process32First(hProcessSnap, &pe32);
	while (bRet)
	{
		// 显示 Process ID
		printf("[%d]\t", pe32.th32ProcessID);

		// 显示 进程名称
		printf("[%s]\n", pe32.szExeFile);

		// 获取快照中下一条信息
		bRet = ::Process32Next(hProcessSnap, &pe32);
	}

	// 关闭句柄
	::CloseHandle(hProcessSnap);

	return TRUE;
}


int _tmain()
{
	// 遍历进程
	if (FALSE == EnumProcess())
	{
		printf("Enum Process Error!\n");
	}

	system("pause");
	return 0;
}
